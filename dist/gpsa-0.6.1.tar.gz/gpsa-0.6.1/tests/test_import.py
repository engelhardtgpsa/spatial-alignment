def test_import():
    from gpsa import VariationalGPSA
