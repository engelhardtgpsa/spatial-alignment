from gpsa.util.util import rbf_kernel_numpy
